﻿
# Cahier des Charges Métier – CryptoTrade
---
open on https://stackedit.io/app# 
---


**CryptoTrade :** Plateforme de Trading Crypto

**Date :** 22/12/2025

**Équipe réalisatrice :** Data & Performance Engineering

**Rôle dans l'équipe :** Chef de projet Data


---

  

## 📌 Contexte Métier

  

CryptoTrade est une plateforme de **trading de cryptomonnaies en temps réel**, permettant à des utilisateurs individuels et institutionnels de passer des ordres, suivre les prix, gérer leurs portefeuilles et analyser le marché.

La plateforme doit supporter des **millions d’ordres et transactions par jour**, tout en fournissant des indicateurs précis pour la prise de décision.

  

### Problèmes identifiés dans la base actuelle

- Latence élevée pour l’affichage des ordres et du carnet de trading

- Requêtes analytiques lentes pour les indicateurs de marché

- Concurrence sur les mises à jour de portefeuille provoquant des deadlocks

- Difficulté à suivre l’activité des utilisateurs inactifs ou suspectés

- Historisation et audit incomplets sur certaines tables

  

---

  

## 📚 Tables de la base de donnée actuel , avec  Description Métier

  

### Table : UTILISATEURS

| Colonne | Description Métier |
|---------|------------------|
| id | Identifiant unique de l’utilisateur sur la plateforme |
| nom | Nom complet de l’utilisateur avec son prénom et son nom de famille, texte maximal de 50 caractères |
| email | Adresse email de l’utilisateur pour contact et notifications, texte maximal de 100 caractères |
| date_inscription | Date à laquelle l’utilisateur a rejoint la plateforme |
| statut | Statut de l’utilisateur indiquant s’il est actif ou inactif |
| portefeuille_id | Référence vers le portefeuille associé à cet utilisateur |

  
**Règles métier :**
- Un utilisateur peut posséder **un ou plusieurs portefeuilles**
- Un utilisateur peut créer **plusieurs ordres**
- Un utilisateur peut être **sujet de plusieurs détections d’anomalies**
- Un utilisateur peut effectuer des actions tracées dans l’audit

---

  

### Table : CRYPTOMONNAIES

| Colonne | Description Métier |
|---------|------------------|
| id | Identifiant unique de la cryptomonnaie sur la plateforme |
| nom | Nom complet de la cryptomonnaie (ex : Bitcoin, Ethereum) |
| symbole | Symbole court utilisé pour trading (ex : BTC, ETH) |
| date_creation | Date de création officielle de la cryptomonnaie |
| statut | Indique si la cryptomonnaie est active ou désactivée sur la plateforme |

**Règles métier :**
- Une cryptomonnaie peut être utilisée comme **crypto de base** ou **crypto de cotation** dans plusieurs paires
- Une cryptomonnaie peut être la **devise de plusieurs portefeuilles**
  

---

  

### Table : PAIRE_TRADING

| Colonne | Description Métier |
|---------|------------------|
| id | Identifiant unique de la paire de trading |
| crypto_base | La cryptomonnaie de base pour la paire (ex : BTC) |
| crypto_contre | La cryptomonnaie ou devise contre laquelle la base est échangée (ex : USDT) |
| statut | Indique si la paire est disponible pour le trading actif |
| date_ouverture | Date de création et activation de la paire sur la plateforme |

  
Les paires de trading définissent les marchés disponibles sur la plateforme.

**Règles métier :**
- Une paire de trading est composée **exactement de deux cryptomonnaies** :
  - une cryptomonnaie de base
  - une cryptomonnaie de cotation
- Une paire peut concerner **plusieurs ordres**
- Une paire peut être associée à **plusieurs trades**
- Une paire possède **un prix de marché courant**
- Une paire possède **plusieurs statistiques de marché**

---

  

### Table : PORTEFEUILLES

| Colonne | Description Métier |
|---------|------------------|
| id | Identifiant unique du portefeuille |
| utilisateur_id | Référence vers l’utilisateur propriétaire du portefeuille |
| solde_total | Montant total détenu par l’utilisateur, exprimé en USD ou cryptomonnaies |
| solde_bloque | Partie du solde réservée pour les ordres en attente ou les transactions en cours |
| date_maj | Date de dernière mise à jour du portefeuille |
|crypto_id | Référence vers la cryptomonnaie du portefeuille



Les portefeuilles représentent les soldes détenus par un utilisateur dans une cryptomonnaie donnée.

**Règles métier :**
- Un utilisateur peut posséder **plusieurs portefeuilles**
- Un portefeuille appartient à **un seul utilisateur**
- Un portefeuille est **libellé dans une seule cryptomonnaie**
- Une cryptomonnaie peut être associée à **plusieurs portefeuilles**
  

---

  

### Table : ORDRES

| Colonne | Description Métier |
|---------|------------------|
| id | Identifiant unique de l’ordre |
| utilisateur_id | Référence vers l’utilisateur qui a passé l’ordre |
| paire_id | Référence vers la paire de trading concernée |
| type_ordre | Type de l’ordre : Achat (Buy) ou Vente (Sell) |
| mode | Mode d’exécution : Market (au prix du marché) ou Limit (au prix limite défini) |
| quantite | Quantité de cryptomonnaie concernée par l’ordre |
| prix | Prix limite pour les ordres de type Limit |
| statut | Statut actuel de l’ordre : en attente, exécuté ou annulé |
| date_creation | Date et heure de création de l’ordre |

  
Les ordres représentent les intentions d’achat ou de vente des utilisateurs.

**Règles métier :**
- Un ordre est créé par **un seul utilisateur**
- Un ordre concerne **une seule paire de trading**
- Un utilisateur peut créer **plusieurs ordres**
- Un ordre peut générer **un ou plusieurs trades**
- Un ordre génère des **entrées dans l’audit**

---

  

### Table : TRADES

| Colonne | Description Métier |
|---------|------------------|
| id | Identifiant unique de la transaction effectuée |
| ordre_id | Référence vers l’ordre qui a été exécuté |
| prix | Prix auquel la transaction a été réalisée |
| quantite | Quantité de cryptomonnaie échangée |
| date_execution | Date et heure de l’exécution du trade |
| paire_id | Référence vers la paire de trading concernée |

  
Les trades représentent l’exécution effective des échanges sur le marché.


**Règles métier :**
- Un trade résulte de l’appariement d’un **ordre d’achat (Buy)** et d’un **ordre de vente (Sell)**
- Un trade est donc associé **fonctionnellement** à deux ordres distincts :
  - un ordre d’ **achat**
  - un ordre de **vente**
- Un ordre d’achat ou de vente peut participer à **un ou plusieurs trades**
- Chaque trade est exécuté sur **une seule paire de trading**
- Un trade génère des **actions d’audit**


  

### Table : PRIX_MARCHE

| Colonne | Description Métier |
|---------|------------------|
| id | Identifiant unique pour chaque enregistrement de prix |
| paire_id | Référence vers la paire de trading concernée |
| prix | Prix courant de la paire sur le marché |
| volume | Volume total échangé sur la période définie |
| date_maj | Date et heure de la dernière mise à jour du prix |

  
Le prix de marché représente l’état courant d’une paire de trading.

**Règles métier :**
- Chaque paire de trading possède **un seul prix de marché courant**
- Le prix est mis à jour en temps réel

---

  

### Table : STATISTIQUE_MARCHE

| Colonne | Description Métier |
|---------|------------------|
| id | Identifiant unique pour l’indicateur |
| paire_id | Référence vers la paire de trading concernée |
| indicateur | Nom de l’indicateur calculé (ex : VWAP, RSI, Volatilité) |
| valeur | Valeur calculée de l’indicateur |
| periode | Période sur laquelle l’indicateur est calculé (ex : 24h, 7j) |
| date_maj | Date et heure de la dernière mise à jour |

  
Les statistiques de marché fournissent des indicateurs d’analyse avancée.

**Règles métier :**
- Une paire de trading peut avoir **plusieurs statistiques**
- Une statistique concerne **une seule paire**
- Les statistiques sont calculées sur différentes périodes temporelles

---

  

### Table : DETECTION_ANOMALIE

| Colonne | Description Métier |
|---------|------------------|
| id | Identifiant unique de l’anomalie détectée |
| type | Type d’anomalie détectée (ex : wash trading, spoofing) |
| ordre_id | Référence vers l’ordre impliqué dans l’anomalie |
| utilisateur_id | Référence vers l’utilisateur suspecté |
| date_detection | Date et heure de la détection de l’anomalie |
| commentaire | Description ou note explicative sur l’anomalie |

  
Les anomalies représentent les comportements suspects détectés sur la plateforme.

**Règles métier :**
- Toute anomalie concerne **un utilisateur**
- Une anomalie peut être liée à **un ordre**
- Un utilisateur peut être sujet à **plusieurs anomalies**
---

  

### Table : AUDIT_TRAIL

| Colonne | Description Métier |
|---------|------------------|
| id | Identifiant unique de l’action auditée |
| table_cible | Nom de la table affectée par l’action |
| record_id | Identifiant du record concerné |
| action | Type d’action : INSERT, UPDATE ou DELETE |
| utilisateur_id | Référence vers l’utilisateur qui a effectué l’action |
| date_action | Date et heure de l’action |
| details | Description détaillée des modifications effectuées |

  L’audit trail assure la traçabilité complète des actions sur la plateforme.

**Règles métier :**
- Une action d’audit est effectuée par **un utilisateur**
- Une action d’audit peut concerner **un ordre**
- Une action d’audit peut concerner **un trade**
- Un utilisateur peut générer **plusieurs entrées d’audit**
---
---

## 🧩 Problèmes à régler et tests de réglage

| Problème identifié | Description Métier | Test de Réglage / Vérification |
|-------------------|------------------|-------------------------------|
| Latence élevée sur affichage des ordres et carnet de trading | Les utilisateurs constatent un délai pour visualiser les ordres actifs et l’état du marché | Mesurer le temps moyen de réponse pour l’affichage du carnet d’ordres avant et après indexation et mise en place de vues matérialisées |
| Requêtes analytiques lentes pour indicateurs de marché | Calcul des indicateurs comme VWAP, RSI ou volatilité sur plusieurs paires prend trop de temps | Comparer le temps d’exécution des requêtes analytiques sur tables brutes vs vues matérialisées et partitionnées |
| Concurrence sur mises à jour de portefeuille (deadlocks) | Plusieurs ordres simultanés entraînent des blocages sur le solde des portefeuilles | Tester les mises à jour concurrentes avec Advisory Locks et vérifier l’absence de deadlocks |
| Historisation et audit incomplets | Certaines actions ne sont pas tracées, compliquant l’audit et la conformité | Vérifier que chaque insertion, modification ou suppression est enregistrée dans AUDIT_TRAIL, avec tests de génération de rapports d’historique |
| Difficulté à détecter anomalies et comportements suspects | Les ordres suspects (wash trading, spoofing) ne sont pas toujours identifiés | Simuler différents scénarios d’anomalies et vérifier leur détection et enregistrement dans DETECTION_ANOMALIE |
| Performance sur tables volumineuses (ORDRES, TRADES, AUDIT_TRAIL) | Tables très volumineuses ralentissent les requêtes de lecture et écriture | Mesurer le temps d’insertion, mise à jour et lecture avant et après partitionnement, index partiel et tuning Fillfactor |
| Cohérence des données utilisateurs et portefeuilles | Doublons ou incohérences dans les emails, noms ou soldes | Vérifier via scripts de nettoyage et standardisation des données, suivi de l’unicité des identifiants |
| Indicateurs de marché non à jour en temps réel | Les prix et indicateurs calculés sont parfois obsolètes | Tester le refresh incrémental des Materialized Views et la mise à jour en temps réel de PRIX_MARCHE |
| Scalabilité face à un pic d’activité | La plateforme doit supporter des millions d’ordres par jour | Simulation de charge massive pour vérifier l’intégrité des transactions et la rapidité des traitements |
| Optimisation des requêtes analytiques multi-colonnes | Les requêtes sur colonnes corrélées sont lentes | Vérifier l’impact des Extended Statistics sur le plan d’exécution des requêtes analytiques |

---

---

  

## 💡 Solutions proposées pour toutes les tables

  

- Standardisation des données (emails, noms) et nettoyage des doublons
- Historisation complète des portefeuilles et ordres pour assurer audit et conformité
- Mise en place de mécanismes transactionnels avancés pour la gestion concurrente
- Optimisation des calculs analytiques (indicateurs de marché) via **Materialized Views**

- Indexation adaptée pour accélérer les recherches et filtrages métier

- Partitionnement et suivi temps réel des tables volumineuses (ORDRES, TRADES, AUDIT_TRAIL)

- Monitoring et alerting proactif pour anomalies et performances

  

---

  

## ⚙️ Contraintes Métier et Optimisation

  

| Technique / Concept | Description / Utilisation |
|--------------------|---------------------------|
| **Vues simples** | Pour reporting métier récurrent sur utilisateurs, portefeuilles, ordres |
| **Materialized Views** | Pré-calculer indicateurs clés de marché pour affichage rapide |
| **Index classiques (B-tree)** | Accélérer recherches par ID et colonnes fréquemment filtrées |
| **Partial Index** | Indexer seulement les ordres actifs ou trades récents |
| **Covering Index / Index-only scan** | Inclure colonnes utiles pour éviter lecture table complète |
| **Extended Statistics** | Colonnes corrélées pour améliorer planification requêtes analytiques |
| **Partitionnement** | Par date ou paire pour tables volumineuses |
| **Advisory Locks** | Sécuriser mises à jour concurrentes sur portefeuille et ordres |
| **Optimisation Work_mem** | Limiter temp file spills sur agrégations lourdes |
| **Fillfactor tuning** | Optimiser HOT updates sur tables très modifiées |

  

---

  

## 🛠 Rappel Technique

  
  

| Concept / Outil | But / Objectif | Types / Options Avancées | Exemple d’Utilisation CryptoTrade |
|------------------------|----------------|-------------------------|----------------------------------|
| **Index** | Accélérer les recherches et filtrages sur les colonnes | B-tree, GIN, BRIN, Partial Index, Covering Index | Index sur `utilisateur_id` dans ORDRES pour retrouver rapidement les ordres actifs d’un utilisateur |
| **Materialized View** | Stocker les résultats pré-calculés pour optimiser les requêtes lourdes | Refresh complet ou incrémental | Vue matérialisée pour le calcul quotidien du VWAP par paire de trading |
| **Window Functions** | Calculer des valeurs analytiques sur un ensemble de lignes (fenêtre) | AVG(), SUM(), ROW_NUMBER(), RANK(), STDDEV() | Calcul des moyennes mobiles sur 24h du prix des cryptos |
| **Recursive CTE** | Parcours hiérarchique ou détection de patterns complexes dans les données | RECURSIVE | Identifier des chaînes d’ordres liés pour détecter des anomalies ou wash trading |
| **Advisory Locks** | Gérer la concurrence et éviter les conflits sur les mises à jour | Session-level ou Transaction-level | Bloquer temporairement l’accès au portefeuille lors de la mise à jour simultanée de plusieurs ordres |
| **Partitionnement** | Découper les tables volumineuses pour optimiser stockage et requêtes | Range Partition, List Partition, Hash Partition | Partitionnement de la table TRADES par date pour accélérer les historiques mensuels |
| **Work_mem** | Mémoire allouée pour les tris et agrégations intermédiaires | Paramétrage par session ou requête | Augmentation pour les calculs de statistiques de marché sur de gros volumes |
| **Fillfactor** | Optimiser les mises à jour fréquentes en laissant de l’espace libre dans les pages | Valeur de 50 à 100% | Paramétrage des pages de la table ORDRES pour réduire les mises à jour coûteuses |
| **Extended Statistics**| Fournir des statistiques sur les colonnes corrélées pour améliorer le planificateur | Multicolumn statistics, Functional statistics | Statistiques sur (`paire_id`, `date_creation`) pour accélérer les requêtes analytiques sur les ordres récents |
